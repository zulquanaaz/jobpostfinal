var mysql = require("mysql");
var express = require("express");
var bodyParser = require("body-parser");
const http = require('http');

// connection to mysql
var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "job",
});




var app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.listen(3000, () => {
  console.log("Restful running on port 3000");
});

app.post("/register/", (req, res, next) => {
  var sqldata = req.body;
  var email = sqldata.email;
  var password = sqldata.password;
 
      var sql = "INSERT INTO user(email,password) VALUES (?,?)";
      var values = [email,password];

      console.log(sql, values);

      con.query(sql, values, function (err, result, fields) {
        con.on("error", (err) => {
          console.log("[MySQL ERROR]", err);
        });
        res.json("Success");
        console.log("Registered" + sqldata);
      });
    
  });



app.post("/addjob/", (req, res, next) => {
  var sqldata = req.body;
  var company = sqldata.company;
  var designation = sqldata.designation;
  var roles = sqldata.roles;
      var sql = "INSERT INTO job (company,designation,roles) VALUES (?,?,?)";
      var values = [company, designation, roles];

      console.log(sql, values);

      con.query(sql, values, function (err, result, fields) {
        con.on("error", (err) => {
          console.log("[MySQL ERROR]", err);
        });
        res.json("Job Added Successfully");
        console.log("Added" + sqldata);
      });
    
  });

app.post("/login/", (req, res, next) => {
    var sqldata = req.body;
    var email = sqldata.email;
    var password = sqldata.password;
  
    con.query("SELECT * FROM user where email = ?", [email], function (
      err,
      result,
      fields
    ) {
      con.on("error", (err) => {
        console.log("[MySQL ERROR]", err);
      });
  
      if (result && result.length) {
        if (password == result[0].password) {
          res.json("Success");
        } else {
          res.json("Invalid user");
        }
      }
    });
  });




  app.get('/getjobs', (req, res) => {
    
    
    con.query("SELECT * FROM job",(err, rows, fields) =>{
      if (!err) 
      res.send(rows)
      else
      console.log(err)

          });
  });
    




  
  



